import { supabase, isSupabaseConfigured } from '@/src/lib/supabase';
import {
  AdminAccessVerification,
  AdminDashboardStats,
  AdminReportItem,
  AdminReportsFilterParams,
  AdminUserItem,
  AdminUsersFilterParams,
  AdminAuditLogItem,
  PaginatedResult,
} from './adminTypes';
import { ReportStatus, ReportReason } from '@/src/modules/moderation/moderationTypes';
import { moderationService } from '@/src/modules/moderation/moderationService';

const LOCAL_STORAGE_PROFILES_KEY = 'dynamo_profiles';
const LOCAL_STORAGE_REPORTS_KEY = 'dynamo_reports';
const LOCAL_STORAGE_DYNAMOS_KEY = 'dynamo_feed_records';
const LOCAL_STORAGE_REPLIES_KEY = 'dynamo_replies';
const LOCAL_STORAGE_MOD_ACTIONS_KEY = 'dynamo_moderation_actions';

export const adminService = {
  /**
   * Verify whether the user has 'admin' or 'moderator' role via server RPC or verified profile.
   * Never trusts unverified client state alone.
   */
  async verifyAccess(userId?: string): Promise<AdminAccessVerification> {
    if (!userId) {
      return {
        isAuthorized: false,
        role: null,
        message: 'Debes iniciar sesión para acceder al panel administrativo.',
      };
    }

    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.rpc('check_admin_access');
        if (error || !data) {
          // Fallback to direct secure profile check if RPC is pending migration
          const { data: prof, error: profErr } = await supabase
            .from('profiles')
            .select('role, username, status')
            .eq('id', userId)
            .single();

          if (profErr || !prof) {
            return {
              isAuthorized: false,
              role: null,
              message: 'No se encontró el perfil de usuario.',
            };
          }

          const hasRole = prof.role === 'admin' || prof.role === 'moderator';
          const isActive = prof.status === 'active';
          return {
            isAuthorized: hasRole && isActive,
            role: hasRole ? prof.role : null,
            username: prof.username,
            userId,
            message: hasRole && isActive ? undefined : 'Acceso denegado: permisos insuficientes.',
          };
        }

        return {
          isAuthorized: Boolean(data.is_authorized),
          role: data.role || null,
          username: data.username,
          userId: data.user_id || userId,
          message: data.message,
        };
      } catch (err: any) {
        return {
          isAuthorized: false,
          role: null,
          message: err.message || 'Error al validar permisos de administrador.',
        };
      }
    }

    // Local sandbox / dev fallback
    const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
    const profiles = rawProfiles ? JSON.parse(rawProfiles) : [];
    const target = profiles.find((p: any) => p.id === userId);

    if (!target) {
      return {
        isAuthorized: false,
        role: null,
        message: 'Usuario no encontrado en la base de datos local.',
      };
    }

    const hasRole = target.role === 'admin' || target.role === 'moderator';
    const isActive = target.status === 'active';

    return {
      isAuthorized: hasRole && isActive,
      role: hasRole ? target.role : null,
      username: target.username,
      userId: target.id,
      message: hasRole && isActive ? undefined : 'Acceso denegado: permisos insuficientes.',
    };
  },

  /**
   * Fetch aggregate administrative stats
   */
  async getDashboardStats(adminUserId: string): Promise<AdminDashboardStats> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.rpc('get_admin_dashboard_stats');
        if (!error && data) {
          return {
            pending_reports: Number(data.pending_reports || 0),
            reviewed_reports: Number(data.reviewed_reports || 0),
            resolved_reports: Number(data.resolved_reports || 0),
            dismissed_reports: Number(data.dismissed_reports || 0),
            suspended_users: Number(data.suspended_users || 0),
            banned_users: Number(data.banned_users || 0),
            hidden_dynamos: Number(data.hidden_dynamos || 0),
            hidden_replies: Number(data.hidden_replies || 0),
            hidden_content: Number(data.hidden_dynamos || 0) + Number(data.hidden_replies || 0),
            total_reports: Number(data.total_reports || 0),
          };
        }
      } catch {
        // Continue to table queries if RPC is not present
      }

      // Supabase manual counts fallback
      const [
        { count: pendingCount },
        { count: reviewedCount },
        { count: resolvedCount },
        { count: dismissedCount },
        { count: suspendedCount },
        { count: bannedCount },
        { count: hiddenDynamosCount },
        { count: hiddenRepliesCount },
      ] = await Promise.all([
        supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'reviewed'),
        supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'resolved'),
        supabase.from('reports').select('*', { count: 'exact', head: true }).eq('status', 'dismissed'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('status', 'suspended'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('status', 'banned'),
        supabase.from('dynamos').select('*', { count: 'exact', head: true }).eq('status', 'hidden'),
        supabase.from('replies').select('*', { count: 'exact', head: true }).eq('status', 'hidden'),
      ]);

      const pend = pendingCount || 0;
      const rev = reviewedCount || 0;
      const res = resolvedCount || 0;
      const dis = dismissedCount || 0;
      const hDyn = hiddenDynamosCount || 0;
      const hRep = hiddenRepliesCount || 0;

      return {
        pending_reports: pend,
        reviewed_reports: rev,
        resolved_reports: res,
        dismissed_reports: dis,
        suspended_users: suspendedCount || 0,
        banned_users: bannedCount || 0,
        hidden_dynamos: hDyn,
        hidden_replies: hRep,
        hidden_content: hDyn + hRep,
        total_reports: pend + rev + res + dis,
      };
    }

    // Local storage computation
    const rawReports = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
    const reports: any[] = rawReports ? JSON.parse(rawReports) : [];

    const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
    const profiles: any[] = rawProfiles ? JSON.parse(rawProfiles) : [];

    const rawDynamos = localStorage.getItem(LOCAL_STORAGE_DYNAMOS_KEY);
    const dynamos: any[] = rawDynamos ? JSON.parse(rawDynamos) : [];

    const rawReplies = localStorage.getItem(LOCAL_STORAGE_REPLIES_KEY);
    const replies: any[] = rawReplies ? JSON.parse(rawReplies) : [];

    const pending = reports.filter((r) => r.status === 'pending').length;
    const reviewed = reports.filter((r) => r.status === 'reviewed').length;
    const resolved = reports.filter((r) => r.status === 'resolved' || r.status === 'actioned').length;
    const dismissed = reports.filter((r) => r.status === 'dismissed').length;

    const suspended = profiles.filter((p) => p.status === 'suspended').length;
    const banned = profiles.filter((p) => p.status === 'banned').length;

    const hiddenDyn = dynamos.filter((d) => d.status === 'hidden').length;
    const hiddenRep = replies.filter((r) => r.status === 'hidden').length;

    return {
      pending_reports: pending,
      reviewed_reports: reviewed,
      resolved_reports: resolved,
      dismissed_reports: dismissed,
      suspended_users: suspended,
      banned_users: banned,
      hidden_dynamos: hiddenDyn,
      hidden_replies: hiddenRep,
      hidden_content: hiddenDyn + hiddenRep,
      total_reports: reports.length,
    };
  },

  /**
   * Get paginated reports inbox with content and author information.
   * Strictly keeps reporter identity anonymous!
   */
  async getReports(
    params: AdminReportsFilterParams,
    adminUserId: string
  ): Promise<PaginatedResult<AdminReportItem>> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    const { status = 'all', category = 'all', contentType = 'all', searchQuery = '', page = 1, pageSize = 10 } = params;

    let items: AdminReportItem[] = [];

    if (isSupabaseConfigured) {
      let query = supabase.from('reports').select('*', { count: 'exact' });

      if (status !== 'all') {
        query = query.eq('status', status);
      }
      if (category !== 'all') {
        query = query.eq('reason', category);
      }
      if (contentType === 'dynamo') {
        query = query.not('dynamo_id', 'is', null);
      } else if (contentType === 'reply') {
        query = query.not('reply_id', 'is', null);
      }

      query = query.order('created_at', { ascending: false });

      const { data: rawReports, error, count } = await query;
      if (error) throw new Error(error.message);

      // Hydrate content & author details without fetching reporter details
      const hydrated: AdminReportItem[] = [];
      for (const r of rawReports || []) {
        let contentText = '[Contenido no disponible]';
        let contentStatus: 'active' | 'hidden' | 'deleted' = 'active';
        let authorId = '';
        let authorUsername = 'usuario_desconocido';
        let authorAvatar = '';

        if (r.dynamo_id) {
          const { data: dyn } = await supabase
            .from('dynamos')
            .select('id, content, status, user_id, profiles:user_id(username, avatar)')
            .eq('id', r.dynamo_id)
            .single();

          if (dyn) {
            contentText = dyn.content;
            contentStatus = dyn.status as any;
            authorId = dyn.user_id;
            authorUsername = (dyn as any).profiles?.username || 'autor_dynamo';
            authorAvatar = (dyn as any).profiles?.avatar || '';
          }
        } else if (r.reply_id) {
          const { data: rep } = await supabase
            .from('replies')
            .select('id, content, status, user_id, profiles:user_id(username, avatar)')
            .eq('id', r.reply_id)
            .single();

          if (rep) {
            contentText = rep.content;
            contentStatus = rep.status as any;
            authorId = rep.user_id;
            authorUsername = (rep as any).profiles?.username || 'autor_respuesta';
            authorAvatar = (rep as any).profiles?.avatar || '';
          }
        }

        hydrated.push({
          id: r.id,
          created_at: r.created_at,
          content_type: r.dynamo_id ? 'dynamo' : 'reply',
          content_id: r.dynamo_id || r.reply_id,
          content_text: contentText,
          content_status: contentStatus,
          author_id: authorId,
          author_username: authorUsername,
          author_avatar: authorAvatar,
          reason: r.reason,
          description: r.description,
          status: r.status,
        });
      }

      items = hydrated;
    } else {
      // Local fallback
      const rawReports = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
      const reports: any[] = rawReports ? JSON.parse(rawReports) : [];

      const rawDynamos = localStorage.getItem(LOCAL_STORAGE_DYNAMOS_KEY);
      const dynamos: any[] = rawDynamos ? JSON.parse(rawDynamos) : [];

      const rawReplies = localStorage.getItem(LOCAL_STORAGE_REPLIES_KEY);
      const replies: any[] = rawReplies ? JSON.parse(rawReplies) : [];

      const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
      const profiles: any[] = rawProfiles ? JSON.parse(rawProfiles) : [];

      items = reports.map((r) => {
        let contentText = '[Contenido no encontrado]';
        let contentStatus: 'active' | 'hidden' | 'deleted' = 'active';
        let authorId = '';
        let authorUsername = 'usuario_local';
        let authorAvatar = '';

        if (r.dynamo_id) {
          const dyn = dynamos.find((d) => d.id === r.dynamo_id);
          if (dyn) {
            contentText = dyn.content;
            contentStatus = dyn.status || 'active';
            authorId = dyn.user_id;
            const authorProf = profiles.find((p) => p.id === dyn.user_id);
            if (authorProf) {
              authorUsername = authorProf.username;
              authorAvatar = authorProf.avatar;
            }
          }
        } else if (r.reply_id) {
          const rep = replies.find((rp) => rp.id === r.reply_id);
          if (rep) {
            contentText = rep.content;
            contentStatus = rep.status || 'active';
            authorId = rep.user_id;
            const authorProf = profiles.find((p) => p.id === rep.user_id);
            if (authorProf) {
              authorUsername = authorProf.username;
              authorAvatar = authorProf.avatar;
            }
          }
        }

        return {
          id: r.id,
          created_at: r.created_at,
          content_type: r.dynamo_id ? 'dynamo' : 'reply',
          content_id: r.dynamo_id || r.reply_id,
          content_text: contentText,
          content_status: contentStatus,
          author_id: authorId,
          author_username: authorUsername,
          author_avatar: authorAvatar,
          reason: r.reason,
          description: r.description,
          status: r.status,
        };
      });
    }

    // Apply client filters if local or search text applied
    let filtered = items;
    if (status !== 'all') {
      filtered = filtered.filter((i) => i.status === status);
    }
    if (category !== 'all') {
      filtered = filtered.filter((i) => i.reason === category);
    }
    if (contentType !== 'all') {
      filtered = filtered.filter((i) => i.content_type === contentType);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(
        (i) =>
          i.content_text.toLowerCase().includes(q) ||
          i.author_username.toLowerCase().includes(q) ||
          (i.description && i.description.toLowerCase().includes(q))
      );
    }

    // Sort by created_at desc
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage = Math.min(Math.max(1, page), totalPages);
    const startIdx = (safePage - 1) * pageSize;
    const paginatedItems = filtered.slice(startIdx, startIdx + pageSize);

    return {
      items: paginatedItems,
      total,
      page: safePage,
      pageSize,
      totalPages,
    };
  },

  /**
   * Apply content moderation action (hide/restore) and update report status
   */
  async moderateContent(
    params: {
      reportId: string;
      newReportStatus?: ReportStatus;
      contentAction?: 'hide_dynamo' | 'restore_dynamo' | 'hide_reply' | 'restore_reply';
      contentId?: string;
      reason: string;
    },
    adminUserId: string
  ): Promise<void> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    const { reportId, newReportStatus, contentAction, contentId, reason } = params;

    // 1. Content action
    if (contentAction === 'hide_dynamo' && contentId) {
      await moderationService.hideDynamo(contentId, adminUserId, reason);
    } else if (contentAction === 'restore_dynamo' && contentId) {
      await moderationService.restoreDynamo(contentId, adminUserId, reason);
    } else if (contentAction === 'hide_reply' && contentId) {
      await moderationService.hideReply(contentId, adminUserId, reason);
    } else if (contentAction === 'restore_reply' && contentId) {
      await moderationService.restoreReply(contentId, adminUserId, reason);
    }

    // 2. Report status update
    if (newReportStatus) {
      await moderationService.updateReportStatus(reportId, newReportStatus, adminUserId, reason);
    }
  },

  /**
   * Suspend, ban, or rehabilitate a user
   * Strictly prevents self-moderation or moderating fellow admins
   */
  async moderateUser(
    params: {
      targetUserId: string;
      action: 'suspend' | 'ban' | 'rehabilitate';
      reason: string;
    },
    adminUserId: string
  ): Promise<void> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    if (params.targetUserId === adminUserId) {
      throw new Error('No puedes aplicar sanciones sobre tu propia cuenta.');
    }

    const { targetUserId, action, reason } = params;
    const newStatus = action === 'suspend' ? 'suspended' : action === 'ban' ? 'banned' : 'active';

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.rpc('admin_moderate_user', {
          p_target_user_id: targetUserId,
          p_action: action,
          p_reason: reason,
        });
        if (error) throw new Error(error.message);
        return;
      } catch {
        // If RPC not applied yet, fall back to update and audit insert
        const { data: targetProf } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', targetUserId)
          .single();

        if (targetProf?.role === 'admin') {
          throw new Error('No se pueden aplicar sanciones sobre administradores del sistema.');
        }

        const { error: updErr } = await supabase
          .from('profiles')
          .update({ status: newStatus })
          .eq('id', targetUserId);
        if (updErr) throw new Error(updErr.message);

        await supabase.from('moderation_actions').insert({
          target_user_id: targetUserId,
          admin_id: adminUserId,
          action: 'user_' + action,
          reason,
        });
        return;
      }
    }

    // Local storage fallback
    const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
    const profiles: any[] = rawProfiles ? JSON.parse(rawProfiles) : [];
    const target = profiles.find((p) => p.id === targetUserId);
    if (!target) throw new Error('Usuario objetivo no encontrado.');

    if (target.role === 'admin') {
      throw new Error('No se pueden aplicar sanciones sobre administradores del sistema.');
    }

    target.status = newStatus;
    localStorage.setItem(LOCAL_STORAGE_PROFILES_KEY, JSON.stringify(profiles));

    moderationService.recordLocalModAction({
      target_user_id: targetUserId,
      admin_id: adminUserId,
      action: 'user_' + action,
      reason,
    });
  },

  /**
   * Get paginated users for user moderation
   * Never exposes private data, passwords or tokens!
   */
  async getUsers(
    params: AdminUsersFilterParams,
    adminUserId: string
  ): Promise<PaginatedResult<AdminUserItem>> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    const { status = 'all', searchQuery = '', page = 1, pageSize = 10 } = params;

    let users: AdminUserItem[] = [];

    if (isSupabaseConfigured) {
      let query = supabase.from('profiles').select('id, username, avatar, role, status, created_at');

      if (status !== 'all') {
        query = query.eq('status', status);
      }

      query = query.order('created_at', { ascending: false });

      const { data, error } = await query;
      if (error) throw new Error(error.message);

      users = (data || []).map((p: any) => ({
        id: p.id,
        username: p.username,
        avatar: p.avatar,
        role: p.role,
        status: p.status,
        created_at: p.created_at,
      }));
    } else {
      const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
      const profiles: any[] = rawProfiles ? JSON.parse(rawProfiles) : [];

      users = profiles.map((p: any) => ({
        id: p.id,
        username: p.username,
        avatar: p.avatar,
        role: p.role,
        status: p.status,
        created_at: p.created_at,
      }));
    }

    let filtered = users;
    if (status !== 'all') {
      filtered = filtered.filter((u) => u.status === status);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      filtered = filtered.filter((u) => u.username.toLowerCase().includes(q));
    }

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage = Math.min(Math.max(1, page), totalPages);
    const startIdx = (safePage - 1) * pageSize;
    const paginated = filtered.slice(startIdx, startIdx + pageSize);

    return {
      items: paginated,
      total,
      page: safePage,
      pageSize,
      totalPages,
    };
  },

  /**
   * Get paginated audit logs
   */
  async getAuditLogs(
    page: number,
    pageSize: number,
    adminUserId: string
  ): Promise<PaginatedResult<AdminAuditLogItem>> {
    const access = await this.verifyAccess(adminUserId);
    if (!access.isAuthorized) {
      throw new Error('Acceso denegado: permisos administrativos requeridos.');
    }

    let logs: AdminAuditLogItem[] = [];

    if (isSupabaseConfigured) {
      const { data, error } = await supabase
        .from('moderation_actions')
        .select('id, admin_id, action, reason, created_at, target_dynamo_id, target_reply_id, target_user_id, profiles:admin_id(username)')
        .order('created_at', { ascending: false });

      if (error) throw new Error(error.message);

      logs = (data || []).map((row: any) => {
        let targetType: 'dynamo' | 'reply' | 'user' = 'dynamo';
        let targetId = '';

        if (row.target_dynamo_id) {
          targetType = 'dynamo';
          targetId = row.target_dynamo_id;
        } else if (row.target_reply_id) {
          targetType = 'reply';
          targetId = row.target_reply_id;
        } else if (row.target_user_id) {
          targetType = 'user';
          targetId = row.target_user_id;
        }

        return {
          id: row.id,
          admin_id: row.admin_id,
          admin_username: row.profiles?.username || 'admin',
          action: row.action,
          target_type: targetType,
          target_id: targetId,
          reason: row.reason,
          created_at: row.created_at,
        };
      });
    } else {
      const rawLogs = localStorage.getItem(LOCAL_STORAGE_MOD_ACTIONS_KEY);
      const localLogs: any[] = rawLogs ? JSON.parse(rawLogs) : [];

      const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
      const profiles: any[] = rawProfiles ? JSON.parse(rawProfiles) : [];

      logs = localLogs.map((l: any) => {
        const adminProf = profiles.find((p) => p.id === l.admin_id);
        let targetType: 'dynamo' | 'reply' | 'user' = 'dynamo';
        let targetId = '';

        if (l.target_dynamo_id) {
          targetType = 'dynamo';
          targetId = l.target_dynamo_id;
        } else if (l.target_reply_id) {
          targetType = 'reply';
          targetId = l.target_reply_id;
        } else if (l.target_user_id) {
          targetType = 'user';
          targetId = l.target_user_id;
        }

        return {
          id: l.id,
          admin_id: l.admin_id,
          admin_username: adminProf?.username || 'admin',
          action: l.action,
          target_type: targetType,
          target_id: targetId,
          reason: l.reason,
          created_at: l.created_at,
        };
      });
    }

    logs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const total = logs.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage = Math.min(Math.max(1, page), totalPages);
    const startIdx = (safePage - 1) * pageSize;
    const paginated = logs.slice(startIdx, startIdx + pageSize);

    return {
      items: paginated,
      total,
      page: safePage,
      pageSize,
      totalPages,
    };
  },
};

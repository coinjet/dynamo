import { supabase, isSupabaseConfigured } from '@/src/lib/supabase';
import { ReportDTO, Report, ReportStatus, ReportReason } from './moderationTypes';
import { sanitizeText, detectSpamPattern } from '@/src/lib/sanitizer';

const LOCAL_STORAGE_REPORTS_KEY = 'dynamo_reports';
const LOCAL_STORAGE_MOD_ACTIONS_KEY = 'dynamo_moderation_actions';
const LOCAL_STORAGE_DYNAMOS_KEY = 'dynamo_feed_records';
const LOCAL_STORAGE_REPLIES_KEY = 'dynamo_replies';
const LOCAL_STORAGE_PROFILES_KEY = 'dynamo_profiles';

// Rate limit: max 10 reports in rolling 1 hour
const MAX_REPORTS_PER_HOUR = 10;
const ONE_HOUR_MS = 60 * 60 * 1000;

export const moderationService = {
  validateContentSafety(text: string): { safe: boolean; reason?: string } {
    if (detectSpamPattern(text)) {
      return { safe: false, reason: 'El mensaje parece spam o contiene caracteres repetidos excesivos.' };
    }

    const forbidden = [/javascript:/i, /<script>/i, /onerror=/i];
    for (const pattern of forbidden) {
      if (pattern.test(text)) {
        return { safe: false, reason: 'Contenido no permitido por razones de seguridad.' };
      }
    }

    return { safe: true };
  },

  /**
   * Checks if user already reported this item (dynamo or reply)
   */
  async hasUserReported(userId: string, dynamoId?: string, replyId?: string): Promise<boolean> {
    if (!userId) return false;
    if (!dynamoId && !replyId) return false;

    if (isSupabaseConfigured) {
      let query = supabase.from('reports').select('id').eq('reporter_id', userId);
      if (dynamoId) {
        query = query.eq('dynamo_id', dynamoId);
      } else if (replyId) {
        query = query.eq('reply_id', replyId);
      }
      const { data, error } = await query.limit(1);
      if (error || !data) return false;
      return data.length > 0;
    }

    const saved = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
    const list: Report[] = saved ? JSON.parse(saved) : [];
    return list.some(
      (r) =>
        r.reporter_id === userId &&
        ((dynamoId && r.dynamo_id === dynamoId) || (replyId && r.reply_id === replyId))
    );
  },

  /**
   * Submit a content report (Dynamo or Reply)
   * Enforces:
   * - No self-reporting
   * - No duplicate reports from the same account
   * - Valid reason category
   * - Rate limit per reporter (max 10/hour)
   * - Max 300 chars sanitized description
   * - Protected reporter anonymity
   */
  async submitReport(dto: ReportDTO, reporterId: string): Promise<Report> {
    if (!reporterId) {
      throw new Error('Debes iniciar sesión para reportar contenido.');
    }

    if (!dto.dynamoId && !dto.replyId) {
      throw new Error('Debes especificar un Dynamo o una respuesta para reportar.');
    }

    if (dto.dynamoId && dto.replyId) {
      throw new Error('No puedes reportar un Dynamo y una respuesta al mismo tiempo.');
    }

    const validReasons: ReportReason[] = [
      'harassment',
      'violence',
      'doxxing',
      'sexual',
      'spam',
      'fraud',
      'impersonation',
      'hate_speech',
      'other',
    ];
    if (!validReasons.includes(dto.reason)) {
      throw new Error('Categoría de reporte no válida.');
    }

    const cleanDescription = dto.description ? sanitizeText(dto.description).slice(0, 300) : '';

    if (isSupabaseConfigured) {
      // Use server-side RPC procedure to guarantee database-level enforcement
      const { data, error } = await supabase.rpc('submit_content_report', {
        p_dynamo_id: dto.dynamoId || null,
        p_reply_id: dto.replyId || null,
        p_reason: dto.reason,
        p_description: cleanDescription || null,
      });

      if (error) {
        throw new Error(error.message);
      }

      return {
        id: data,
        reporter_id: reporterId,
        dynamo_id: dto.dynamoId || null,
        reply_id: dto.replyId || null,
        reason: dto.reason,
        description: cleanDescription || null,
        status: 'pending',
        created_at: new Date().toISOString(),
      };
    }

    // Local Storage fallback with identical business rule enforcement
    const saved = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
    const list: Report[] = saved ? JSON.parse(saved) : [];

    // 1. Rate limit check (max 10 per hour)
    const now = Date.now();
    const recentReports = list.filter(
      (r) => r.reporter_id === reporterId && now - new Date(r.created_at).getTime() < ONE_HOUR_MS
    );
    if (recentReports.length >= MAX_REPORTS_PER_HOUR) {
      throw new Error(
        `Has alcanzado el límite temporal de reportes (${MAX_REPORTS_PER_HOUR} por hora). Inténtalo más tarde.`
      );
    }

    // 2. Dynamo Target check
    if (dto.dynamoId) {
      const rawDynamos = localStorage.getItem(LOCAL_STORAGE_DYNAMOS_KEY);
      const dynamos = rawDynamos ? JSON.parse(rawDynamos) : [];
      const targetDynamo = dynamos.find((d: any) => d.id === dto.dynamoId);

      if (!targetDynamo) {
        throw new Error('La publicación que intentas reportar no existe.');
      }

      // No self-reporting
      if (targetDynamo.user_id === reporterId) {
        throw new Error('No puedes reportar tu propio contenido.');
      }

      // No duplicate reports
      const alreadyReported = list.some(
        (r) => r.reporter_id === reporterId && r.dynamo_id === dto.dynamoId
      );
      if (alreadyReported) {
        throw new Error('Ya has reportado esta publicación previamente.');
      }
    }

    // 3. Reply Target check
    if (dto.replyId) {
      const rawReplies = localStorage.getItem(LOCAL_STORAGE_REPLIES_KEY);
      const replies = rawReplies ? JSON.parse(rawReplies) : [];
      const targetReply = replies.find((r: any) => r.id === dto.replyId);

      if (!targetReply) {
        throw new Error('La respuesta que intentas reportar no existe.');
      }

      // No self-reporting
      if (targetReply.user_id === reporterId) {
        throw new Error('No puedes reportar tu propia respuesta.');
      }

      // No duplicate reports
      const alreadyReported = list.some(
        (r) => r.reporter_id === reporterId && r.reply_id === dto.replyId
      );
      if (alreadyReported) {
        throw new Error('Ya has reportado esta respuesta previamente.');
      }
    }

    const newReport: Report = {
      id: 'rep_' + Math.random().toString(36).substring(2, 9),
      reporter_id: reporterId,
      dynamo_id: dto.dynamoId || null,
      reply_id: dto.replyId || null,
      reason: dto.reason,
      description: cleanDescription || null,
      status: 'pending',
      created_at: new Date().toISOString(),
    };

    list.push(newReport);
    localStorage.setItem(LOCAL_STORAGE_REPORTS_KEY, JSON.stringify(list));
    return newReport;
  },

  // ============================================================================
  // ADMINISTRATIVE / MODERATION BACKEND API
  // Note: NO full dashboard is created per directive; these functions provide the
  // secure database & API operations for authorized moderators/admins.
  // ============================================================================

  /**
   * Query reports (restricted to admin/moderator roles)
   */
  async getReports(adminUserId: string, filterStatus?: ReportStatus): Promise<Report[]> {
    if (!adminUserId) throw new Error('No autorizado.');

    if (isSupabaseConfigured) {
      let query = supabase.from('reports').select('*').order('created_at', { ascending: false });
      if (filterStatus) {
        query = query.eq('status', filterStatus);
      }
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return data || [];
    }

    // Local fallback: verify admin role
    const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
    const profiles = rawProfiles ? JSON.parse(rawProfiles) : [];
    const admin = profiles.find((p: any) => p.id === adminUserId);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'moderator')) {
      throw new Error('Acceso denegado: se requieren privilegios administrativos.');
    }

    const saved = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
    const list: Report[] = saved ? JSON.parse(saved) : [];
    if (filterStatus) {
      return list.filter((r) => r.status === filterStatus);
    }
    return list;
  },

  /**
   * Update report review status: pending / reviewed / resolved / dismissed
   */
  async updateReportStatus(
    reportId: string,
    newStatus: ReportStatus,
    adminUserId: string,
    reason?: string
  ): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase.rpc('moderate_content', {
        p_report_id: reportId,
        p_new_report_status: newStatus,
        p_content_action: null,
        p_reason: reason || null,
      });
      if (error) throw new Error(error.message);
      return;
    }

    const saved = localStorage.getItem(LOCAL_STORAGE_REPORTS_KEY);
    const list: Report[] = saved ? JSON.parse(saved) : [];
    const report = list.find((r) => r.id === reportId);
    if (!report) throw new Error('Reporte no encontrado.');

    report.status = newStatus;
    localStorage.setItem(LOCAL_STORAGE_REPORTS_KEY, JSON.stringify(list));
  },

  /**
   * Hide a Dynamo from feeds, discovery, energy gifts, and replies
   */
  async hideDynamo(dynamoId: string, adminUserId: string, reason?: string): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase
        .from('dynamos')
        .update({ status: 'hidden' })
        .eq('id', dynamoId);
      if (error) throw new Error(error.message);

      await supabase.from('moderation_actions').insert({
        target_dynamo_id: dynamoId,
        admin_id: adminUserId,
        action: 'hide_dynamo',
        reason: reason || 'Ocultado por moderación',
      });
      return;
    }

    const rawDynamos = localStorage.getItem(LOCAL_STORAGE_DYNAMOS_KEY);
    const dynamos = rawDynamos ? JSON.parse(rawDynamos) : [];
    const target = dynamos.find((d: any) => d.id === dynamoId);
    if (!target) throw new Error('Dynamo no encontrado.');

    target.status = 'hidden';
    localStorage.setItem(LOCAL_STORAGE_DYNAMOS_KEY, JSON.stringify(dynamos));

    // Log action
    this.recordLocalModAction({
      target_dynamo_id: dynamoId,
      admin_id: adminUserId,
      action: 'hide_dynamo',
      reason: reason || 'Ocultado por moderación',
    });
  },

  /**
   * Restore a hidden Dynamo to active status
   */
  async restoreDynamo(dynamoId: string, adminUserId: string, reason?: string): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase
        .from('dynamos')
        .update({ status: 'active' })
        .eq('id', dynamoId);
      if (error) throw new Error(error.message);

      await supabase.from('moderation_actions').insert({
        target_dynamo_id: dynamoId,
        admin_id: adminUserId,
        action: 'restore_dynamo',
        reason: reason || 'Restaurado por moderación',
      });
      return;
    }

    const rawDynamos = localStorage.getItem(LOCAL_STORAGE_DYNAMOS_KEY);
    const dynamos = rawDynamos ? JSON.parse(rawDynamos) : [];
    const target = dynamos.find((d: any) => d.id === dynamoId);
    if (!target) throw new Error('Dynamo no encontrado.');

    target.status = 'active';
    localStorage.setItem(LOCAL_STORAGE_DYNAMOS_KEY, JSON.stringify(dynamos));

    this.recordLocalModAction({
      target_dynamo_id: dynamoId,
      admin_id: adminUserId,
      action: 'restore_dynamo',
      reason: reason || 'Restaurado por moderación',
    });
  },

  /**
   * Hide a reply from views
   */
  async hideReply(replyId: string, adminUserId: string, reason?: string): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase
        .from('replies')
        .update({ status: 'hidden' })
        .eq('id', replyId);
      if (error) throw new Error(error.message);

      await supabase.from('moderation_actions').insert({
        target_reply_id: replyId,
        admin_id: adminUserId,
        action: 'hide_reply',
        reason: reason || 'Ocultado por moderación',
      });
      return;
    }

    const rawReplies = localStorage.getItem(LOCAL_STORAGE_REPLIES_KEY);
    const replies = rawReplies ? JSON.parse(rawReplies) : [];
    const target = replies.find((r: any) => r.id === replyId);
    if (!target) throw new Error('Respuesta no encontrada.');

    target.status = 'hidden';
    localStorage.setItem(LOCAL_STORAGE_REPLIES_KEY, JSON.stringify(replies));

    this.recordLocalModAction({
      target_reply_id: replyId,
      admin_id: adminUserId,
      action: 'hide_reply',
      reason: reason || 'Ocultado por moderación',
    });
  },

  /**
   * Restore a hidden reply
   */
  async restoreReply(replyId: string, adminUserId: string, reason?: string): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase
        .from('replies')
        .update({ status: 'active' })
        .eq('id', replyId);
      if (error) throw new Error(error.message);

      await supabase.from('moderation_actions').insert({
        target_reply_id: replyId,
        admin_id: adminUserId,
        action: 'restore_reply',
        reason: reason || 'Restaurada por moderación',
      });
      return;
    }

    const rawReplies = localStorage.getItem(LOCAL_STORAGE_REPLIES_KEY);
    const replies = rawReplies ? JSON.parse(rawReplies) : [];
    const target = replies.find((r: any) => r.id === replyId);
    if (!target) throw new Error('Respuesta no encontrada.');

    target.status = 'active';
    localStorage.setItem(LOCAL_STORAGE_REPLIES_KEY, JSON.stringify(replies));

    this.recordLocalModAction({
      target_reply_id: replyId,
      admin_id: adminUserId,
      action: 'restore_reply',
      reason: reason || 'Restaurada por moderación',
    });
  },

  /**
   * Restrict, suspend or restore a user account
   */
  async setUserStatus(
    targetUserId: string,
    status: 'active' | 'restricted' | 'suspended',
    adminUserId: string,
    reason?: string
  ): Promise<void> {
    if (isSupabaseConfigured) {
      const { error } = await supabase.rpc('moderate_user', {
        p_target_user_id: targetUserId,
        p_new_status: status,
        p_reason: reason || null,
      });
      if (error) throw new Error(error.message);
      return;
    }

    const rawProfiles = localStorage.getItem(LOCAL_STORAGE_PROFILES_KEY);
    const profiles = rawProfiles ? JSON.parse(rawProfiles) : [];
    const target = profiles.find((p: any) => p.id === targetUserId);
    if (!target) throw new Error('Usuario no encontrado.');

    if (target.role === 'admin') {
      throw new Error('No se puede sancionar a un administrador del sistema.');
    }

    target.status = status;
    localStorage.setItem(LOCAL_STORAGE_PROFILES_KEY, JSON.stringify(profiles));

    this.recordLocalModAction({
      target_user_id: targetUserId,
      admin_id: adminUserId,
      action: 'user_status_' + status,
      reason: reason || `Estado cambiado a ${status}`,
    });
  },

  recordLocalModAction(actionData: {
    target_dynamo_id?: string;
    target_reply_id?: string;
    target_user_id?: string;
    admin_id: string;
    action: string;
    reason: string;
  }) {
    const raw = localStorage.getItem(LOCAL_STORAGE_MOD_ACTIONS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    list.push({
      id: 'act_' + Math.random().toString(36).substring(2, 9),
      ...actionData,
      created_at: new Date().toISOString(),
    });
    localStorage.setItem(LOCAL_STORAGE_MOD_ACTIONS_KEY, JSON.stringify(list));
  },
};

import { supabase, isSupabaseConfigured } from '@/src/lib/supabase';
import {
  UserProfile,
  SignInParams,
  SignUpParams,
  AuthSession,
  ResetPasswordParams,
  UpdatePasswordParams,
} from './authTypes';
import {
  validateEmail,
  validatePassword,
  validateUsername,
  sanitizeAndValidateBio,
  AUTH_LIMITS,
} from './authValidation';
import { profilesService } from '@/src/modules/profiles/profilesService';

const LOCAL_STORAGE_SESSION_KEY = 'dynamo_auth_session';

const DEFAULT_DEMO_USER: UserProfile = {
  id: 'usr_f891a2b3-4c5d-6e7f-8a9b-0c1d2e3f4a5b',
  username: 'sol_valenzuela',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&h=256&q=80',
  bio: 'Cronista nocturna. ⚡',
  created_at: '2026-08-15T12:00:00Z',
  role: 'user',
  status: 'active',
};

export const authService = {
  /**
   * Retrieves active session from Supabase or local sandbox.
   */
  async getInitialSession(): Promise<AuthSession | null> {
    if (isSupabaseConfigured) {
      try {
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession();
        if (error || !session) return null;

        const profile = await profilesService.getProfile(session.user.id);
        if (profile) {
          return {
            user: { id: session.user.id, email: session.user.email },
            profile,
          };
        }
      } catch (err) {
        console.warn('Error al verificar sesión de Supabase:', err);
      }
    }

    // In production without Supabase, never mock sessions or use demo accounts
    if (import.meta.env.PROD && !isSupabaseConfigured) {
      return null;
    }

    // Local-first sandbox fallback (strictly development)
    const saved = localStorage.getItem(LOCAL_STORAGE_SESSION_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // invalid json
      }
    }

    // In development mode only, provide sandbox session
    if (import.meta.env.DEV) {
      const defaultSession: AuthSession = {
        user: { id: DEFAULT_DEMO_USER.id, email: 'sandbox@dynamo.local' },
        profile: DEFAULT_DEMO_USER,
      };
      localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(defaultSession));
      return defaultSession;
    }

    return null;
  },

  /**
   * Register with email, password, confirmPassword, username, legal consent and min age check.
   */
  async signUp(params: SignUpParams): Promise<AuthSession> {
    // 1. Mandatory legal and age agreements
    if (!params.acceptedTerms || !params.acceptedPrivacy || !params.acceptedCommunityGuidelines) {
      throw new Error(
        'Debes aceptar los Términos de Servicio, la Política de Privacidad y las Normas de la Comunidad para registrarte.'
      );
    }

    if (!params.isAgeConfirmed) {
      throw new Error(
        `Debes confirmar que tienes al menos ${AUTH_LIMITS.MIN_AGE} años para usar Dynamo.`
      );
    }

    // 2. Validate email
    const emailCheck = validateEmail(params.email);
    if (!emailCheck.isValid) {
      throw new Error(emailCheck.error || 'Correo electrónico inválido.');
    }

    // 3. Validate password strength
    const passwordCheck = validatePassword(params.password);
    if (!passwordCheck.isValid) {
      throw new Error(passwordCheck.error || 'Contraseña no cumple con los requisitos de seguridad.');
    }

    // 4. Validate password confirmation
    if (params.password !== params.confirmPassword) {
      throw new Error('Las contraseñas no coinciden.');
    }

    // 5. Validate username
    const cleanUsername = params.username.trim().toLowerCase();
    const usernameCheck = validateUsername(cleanUsername);
    if (!usernameCheck.isValid) {
      throw new Error(usernameCheck.error || 'Nombre de usuario inválido.');
    }

    // 6. Check username uniqueness
    const isAvailable = await profilesService.isUsernameAvailable(cleanUsername);
    if (!isAvailable) {
      throw new Error('El nombre de usuario ya está en uso. Por favor elige otro.');
    }

    // 7. Sanitize bio if provided
    let cleanBio = '';
    if (params.bio) {
      const bioCheck = sanitizeAndValidateBio(params.bio);
      if (!bioCheck.isValid) {
        throw new Error(bioCheck.error || 'Biografía no válida.');
      }
      cleanBio = bioCheck.sanitized;
    }

    // Production check
    if (import.meta.env.PROD && !isSupabaseConfigured) {
      throw new Error('Error de configuración: Supabase no está conectado en producción.');
    }

    // Supabase Authentication
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.auth.signUp({
        email: params.email.trim(),
        password: params.password,
        options: {
          data: {
            username: cleanUsername,
            bio: cleanBio,
          },
        },
      });

      if (error) {
        // Normalize error message without leaking sensitive internal details
        if (error.message.toLowerCase().includes('already registered')) {
          throw new Error('Este correo ya se encuentra registrado. Intenta iniciar sesión.');
        }
        throw new Error(error.message);
      }

      if (!data.user) {
        throw new Error('No se pudo crear la cuenta. Intenta de nuevo.');
      }

      // Fetch profile created securely by server-side trigger handle_new_user()
      const { data: fetchedProfile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .maybeSingle();

      const profile: UserProfile = fetchedProfile
        ? (fetchedProfile as UserProfile)
        : {
            id: data.user.id,
            username: cleanUsername,
            avatar: '',
            bio: cleanBio,
            created_at: data.user.created_at || new Date().toISOString(),
            role: 'user',
            status: 'active',
          };

      return {
        user: { id: data.user.id, email: data.user.email },
        profile,
      };
    }

    // Local Development Sandbox
    const newId = 'usr_' + Math.random().toString(36).substring(2, 10);
    const newProfile: UserProfile = {
      id: newId,
      username: cleanUsername,
      avatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${cleanUsername}`,
      bio: cleanBio || 'Explorador en Dynamo.',
      created_at: new Date().toISOString(),
      role: 'user',
      status: 'active',
    };

    const session: AuthSession = {
      user: { id: newId, email: params.email.trim() },
      profile: newProfile,
    };

    localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(session));
    return session;
  },

  /**
   * Log in with email + password. Generic error message prevents credential enumeration.
   */
  async signIn(params: SignInParams): Promise<AuthSession> {
    const email = params.email.trim();
    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid || !params.password) {
      throw new Error('Credenciales inválidas. Por favor verifica tu correo y contraseña.');
    }

    if (import.meta.env.PROD && !isSupabaseConfigured) {
      throw new Error('Error de configuración: Supabase no está conectado en producción.');
    }

    if (isSupabaseConfigured) {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password: params.password,
      });

      if (error || !data.user) {
        // Generic security-conscious error
        throw new Error('Credenciales incorrectas. Por favor verifica tu correo y contraseña.');
      }

      let profile = await profilesService.getProfile(data.user.id);
      if (!profile) {
        // Fallback create profile if missing
        profile = {
          id: data.user.id,
          username: email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '') || 'usuario',
          avatar: '',
          bio: '',
          created_at: new Date().toISOString(),
          role: 'user',
          status: 'active',
        };
        await supabase.from('profiles').upsert(profile);
      }

      return {
        user: { id: data.user.id, email: data.user.email },
        profile,
      };
    }

    // Local Sandbox sign in
    const session: AuthSession = {
      user: { id: DEFAULT_DEMO_USER.id, email },
      profile: {
        ...DEFAULT_DEMO_USER,
        username: email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '') || DEFAULT_DEMO_USER.username,
      },
    };
    localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, JSON.stringify(session));
    return session;
  },

  /**
   * Request password recovery link via Supabase Auth.
   * Safe response prevents email enumeration.
   */
  async sendPasswordReset(params: ResetPasswordParams): Promise<{ message: string }> {
    const email = params.email.trim();
    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) {
      throw new Error(emailCheck.error || 'Correo electrónico inválido.');
    }

    if (isSupabaseConfigured) {
      const redirectUrl = window.location.origin;
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl,
      });

      if (error) {
        console.warn('Supabase password reset warning:', error.message);
      }
    }

    return {
      message: 'Si el correo electrónico existe en Dynamo, recibirás un enlace para restablecer tu contraseña.',
    };
  },

  /**
   * Update password for an authenticated session or recovery token.
   */
  async updatePassword(params: UpdatePasswordParams): Promise<void> {
    const passwordCheck = validatePassword(params.newPassword);
    if (!passwordCheck.isValid) {
      throw new Error(passwordCheck.error || 'La nueva contraseña no cumple los requisitos de seguridad.');
    }

    if (params.confirmPassword && params.newPassword !== params.confirmPassword) {
      throw new Error('Las contraseñas no coinciden.');
    }

    if (isSupabaseConfigured) {
      const { error } = await supabase.auth.updateUser({
        password: params.newPassword,
      });

      if (error) {
        throw new Error(error.message || 'No se pudo actualizar la contraseña.');
      }
    }
  },

  /**
   * Log out and terminate persistent session.
   */
  async signOut(): Promise<void> {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
    localStorage.removeItem(LOCAL_STORAGE_SESSION_KEY);
  },
};

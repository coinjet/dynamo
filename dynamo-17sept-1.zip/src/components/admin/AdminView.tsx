import React, { useState, useEffect } from 'react';
import { useAuth } from '@/src/modules/auth/AuthContext';
import { adminService } from '@/src/modules/admin/adminService';
import { AdminAccessVerification, AdminDashboardStats } from '@/src/modules/admin/adminTypes';
import { AdminDashboard } from './AdminDashboard';
import { AdminReportsInbox } from './AdminReportsInbox';
import { AdminUsersView } from './AdminUsersView';
import { AdminAuditView } from './AdminAuditView';
import {
  AlertTriangle,
  ArrowLeft,
  Clock,
  FileText,
  LayoutDashboard,
  Shield,
  ShieldAlert,
  Users,
  Lock,
} from 'lucide-react';
import { isSupabaseConfigured } from '@/src/lib/supabase';

interface AdminViewProps {
  onGoToHome: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onGoToHome }) => {
  const { user, profile, updateProfileState } = useAuth();
  const [access, setAccess] = useState<AdminAccessVerification | null>(null);
  const [isVerifying, setIsVerifying] = useState(true);

  // Active Admin Sub-tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'users' | 'audit'>('dashboard');
  const [reportsInitialFilter, setReportsInitialFilter] = useState<string | undefined>(undefined);
  const [usersInitialFilter, setUsersInitialFilter] = useState<string | undefined>(undefined);

  // Stats State
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState(false);

  const checkAccess = async () => {
    setIsVerifying(true);
    try {
      const verification = await adminService.verifyAccess(user?.id);
      setAccess(verification);
      if (verification.isAuthorized && user?.id) {
        loadStats(user.id);
      }
    } catch {
      setAccess({
        isAuthorized: false,
        role: null,
        message: 'Error al verificar permisos en el servidor.',
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const loadStats = async (adminId: string) => {
    setIsLoadingStats(true);
    try {
      const s = await adminService.getDashboardStats(adminId);
      setStats(s);
    } catch (err) {
      console.warn('Error loading stats:', err);
    } finally {
      setIsLoadingStats(false);
    }
  };

  useEffect(() => {
    checkAccess();
  }, [user?.id, profile?.role]);

  const handleNavigateFromDashboard = (tab: 'reports' | 'users' | 'audit', filter?: string) => {
    if (tab === 'reports') {
      setReportsInitialFilter(filter);
    } else if (tab === 'users') {
      setUsersInitialFilter(filter);
    }
    setActiveTab(tab);
  };

  // Sandbox Role Switcher (ONLY available in local dev sandbox for evaluation)
  const handleSandboxRoleSwitch = (newRole: 'user' | 'moderator' | 'admin') => {
    if (isSupabaseConfigured) return;

    // Update in local profile store
    const localStore = localStorage.getItem('dynamo_profiles');
    const profiles = localStore ? JSON.parse(localStore) : [];
    const idx = profiles.findIndex((p: any) => p.id === user?.id);
    if (idx >= 0) {
      profiles[idx].role = newRole;
      localStorage.setItem('dynamo_profiles', JSON.stringify(profiles));
    }

    // Update mock store
    const rawMock = localStorage.getItem('dynamo_mock_profiles_store');
    if (rawMock) {
      try {
        const mockMap = JSON.parse(rawMock);
        if (mockMap[user?.id || '']) {
          mockMap[user!.id].role = newRole;
          localStorage.setItem('dynamo_mock_profiles_store', JSON.stringify(mockMap));
        }
      } catch {}
    }

    updateProfileState({ role: newRole });
    checkAccess();
  };

  // 1. Loading State
  if (isVerifying) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-4 px-4">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-amber-500 border-r-transparent" />
        <p className="text-xs text-stone-400 font-mono">
          Verificando credenciales administrativas en el servidor...
        </p>
      </div>
    );
  }

  // 2. Access Denied State (Normal Users)
  if (!access || !access.isAuthorized) {
    return (
      <div className="max-w-md mx-auto my-16 px-4">
        <div className="bg-[#161B21] border border-red-500/30 rounded-2xl p-6 sm:p-8 text-center space-y-5 shadow-xl">
          <div className="w-14 h-14 rounded-2xl bg-red-950/60 border border-red-500/30 flex items-center justify-center mx-auto text-red-400">
            <Lock className="w-7 h-7" />
          </div>

          <div className="space-y-2">
            <h2 className="text-xl font-bold text-white tracking-tight">Acceso Denegado</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              Esta sección está estrictamente reservada para administradores y moderadores de
              Dynamo. Tu cuenta (<span className="text-stone-300 font-medium font-mono">@{profile?.username || 'anónimo'}</span>)
              tiene rol de <span className="text-amber-400 font-semibold font-mono">{profile?.role || 'usuario'}</span> y
              no posee privilegios para consultar reportes ni ejecutar acciones de moderación.
            </p>
          </div>

          <div className="pt-2 border-t border-stone-800 space-y-3">
            <button
              onClick={onGoToHome}
              className="w-full py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold transition"
            >
              ← Volver al inicio de Dynamo
            </button>

            {/* Local Sandbox Evaluator Helper */}
            {!isSupabaseConfigured && (
              <div className="mt-4 p-3 bg-stone-900/80 rounded-xl border border-stone-800 text-left space-y-2">
                <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" />
                  Modo de Prueba Local (Sandbox):
                </span>
                <p className="text-[10px] text-stone-400 leading-normal">
                  Puedes alternar tu rol local para validar el panel administrativo sin tocar
                  producción:
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleSandboxRoleSwitch('admin')}
                    className="flex-1 py-1 px-2 rounded bg-amber-500 hover:bg-amber-400 text-black text-[11px] font-semibold transition"
                  >
                    Asignar Admin
                  </button>
                  <button
                    onClick={() => handleSandboxRoleSwitch('moderator')}
                    className="flex-1 py-1 px-2 rounded bg-stone-800 hover:bg-stone-700 text-stone-200 text-[11px] font-medium transition"
                  >
                    Asignar Moderador
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 3. Authorized Admin Panel View
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Header & Role Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onGoToHome}
            className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition"
            title="Volver a Dynamo"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                Panel de Administración
              </h1>
              <span
                className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full border ${
                  access.role === 'admin'
                    ? 'bg-red-500/10 text-red-400 border-red-500/30'
                    : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                }`}
              >
                {access.role}
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-0.5">
              Gestión de reportes, moderación de contenido y control de usuarios.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center text-xs">
          <span className="text-stone-400">Sesión activa:</span>
          <span className="font-semibold text-white font-mono">@{access.username}</span>

          {/* Sandbox Toggle Back to Normal User */}
          {!isSupabaseConfigured && (
            <button
              onClick={() => handleSandboxRoleSwitch('user')}
              className="ml-2 text-[10px] text-stone-500 hover:text-amber-400 underline"
              title="Probar vista como usuario normal para verificar acceso denegado"
            >
              (Probar rol usuario)
            </button>
          )}
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-stone-800 scrollbar-none text-xs">
        <button
          id="btn-admin-tab-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition shrink-0 ${
            activeTab === 'dashboard'
              ? 'bg-amber-500 text-black font-semibold'
              : 'text-stone-400 hover:text-white hover:bg-stone-800/60'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          id="btn-admin-tab-reports"
          onClick={() => setActiveTab('reports')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition shrink-0 ${
            activeTab === 'reports'
              ? 'bg-amber-500 text-black font-semibold'
              : 'text-stone-400 hover:text-white hover:bg-stone-800/60'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Bandeja de Reportes</span>
          {stats && stats.pending_reports > 0 && (
            <span
              className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'reports' ? 'bg-black text-amber-400' : 'bg-amber-500/20 text-amber-400'
              }`}
            >
              {stats.pending_reports}
            </span>
          )}
        </button>

        <button
          id="btn-admin-tab-users"
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition shrink-0 ${
            activeTab === 'users'
              ? 'bg-amber-500 text-black font-semibold'
              : 'text-stone-400 hover:text-white hover:bg-stone-800/60'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Moderación de Usuarios</span>
          {stats && stats.suspended_users + stats.banned_users > 0 && (
            <span
              className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'users' ? 'bg-black text-amber-400' : 'bg-orange-500/20 text-orange-400'
              }`}
            >
              {stats.suspended_users + stats.banned_users}
            </span>
          )}
        </button>

        <button
          id="btn-admin-tab-audit"
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium transition shrink-0 ${
            activeTab === 'audit'
              ? 'bg-amber-500 text-black font-semibold'
              : 'text-stone-400 hover:text-white hover:bg-stone-800/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Registro de Auditoría</span>
        </button>
      </div>

      {/* Tab Content Panels */}
      <div>
        {activeTab === 'dashboard' && (
          <AdminDashboard
            stats={stats}
            isLoading={isLoadingStats}
            onNavigateTab={handleNavigateFromDashboard}
          />
        )}

        {activeTab === 'reports' && user?.id && (
          <AdminReportsInbox
            adminUserId={user.id}
            initialStatusFilter={reportsInitialFilter}
            onRefreshStats={() => loadStats(user.id)}
          />
        )}

        {activeTab === 'users' && user?.id && (
          <AdminUsersView
            adminUserId={user.id}
            initialFilter={usersInitialFilter}
            onRefreshStats={() => loadStats(user.id)}
          />
        )}

        {activeTab === 'audit' && user?.id && <AdminAuditView adminUserId={user.id} />}
      </div>
    </div>
  );
};

import React from 'react';
import { AdminDashboardStats } from '@/src/modules/admin/adminTypes';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Eye,
  ShieldAlert,
  Slash,
  UserX,
  FileText,
  Lock,
} from 'lucide-react';

interface AdminDashboardProps {
  stats: AdminDashboardStats | null;
  isLoading: boolean;
  onNavigateTab: (tab: 'reports' | 'users' | 'audit', filter?: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  stats,
  isLoading,
  onNavigateTab,
}) => {
  if (isLoading) {
    return (
      <div className="py-12 flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-amber-500 border-r-transparent" />
      </div>
    );
  }

  const s = stats || {
    pending_reports: 0,
    reviewed_reports: 0,
    resolved_reports: 0,
    dismissed_reports: 0,
    suspended_users: 0,
    banned_users: 0,
    hidden_dynamos: 0,
    hidden_replies: 0,
    hidden_content: 0,
    total_reports: 0,
  };

  return (
    <div className="space-y-6">
      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* Pending Reports */}
        <div
          id="stat-pending-reports"
          onClick={() => onNavigateTab('reports', 'pending')}
          className="bg-[#161B21] border border-amber-500/30 rounded-xl p-4 cursor-pointer hover:border-amber-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-amber-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              Pendientes
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
              Urgente
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-amber-400 transition">
            {s.pending_reports}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">Reportes esperando revisión</p>
        </div>

        {/* Reviewed Reports */}
        <div
          id="stat-reviewed-reports"
          onClick={() => onNavigateTab('reports', 'reviewed')}
          className="bg-[#161B21] border border-sky-500/30 rounded-xl p-4 cursor-pointer hover:border-sky-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-sky-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5" />
              Revisados
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-sky-400 transition">
            {s.reviewed_reports}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">En proceso de moderación</p>
        </div>

        {/* Resolved Reports */}
        <div
          id="stat-resolved-reports"
          onClick={() => onNavigateTab('reports', 'resolved')}
          className="bg-[#161B21] border border-emerald-500/30 rounded-xl p-4 cursor-pointer hover:border-emerald-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-emerald-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Resueltos
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-emerald-400 transition">
            {s.resolved_reports}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">Acción tomada y cerrados</p>
        </div>

        {/* Dismissed Reports */}
        <div
          id="stat-dismissed-reports"
          onClick={() => onNavigateTab('reports', 'dismissed')}
          className="bg-[#161B21] border border-stone-800 rounded-xl p-4 cursor-pointer hover:border-stone-700 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <Slash className="w-3.5 h-3.5" />
              Descartados
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-stone-200 group-hover:text-white transition">
            {s.dismissed_reports}
          </div>
          <p className="text-[11px] text-stone-500 mt-1">Sin infracción o falsos</p>
        </div>

        {/* Suspended Users */}
        <div
          id="stat-suspended-users"
          onClick={() => onNavigateTab('users', 'suspended')}
          className="bg-[#161B21] border border-orange-500/30 rounded-xl p-4 cursor-pointer hover:border-orange-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-orange-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <UserX className="w-3.5 h-3.5" />
              Suspendidos
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-orange-400 transition">
            {s.suspended_users}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">Cuentas con sanción temporal</p>
        </div>

        {/* Banned Users */}
        <div
          id="stat-banned-users"
          onClick={() => onNavigateTab('users', 'banned')}
          className="bg-[#161B21] border border-red-500/30 rounded-xl p-4 cursor-pointer hover:border-red-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-red-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5" />
              Bloqueados / Baneados
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-red-400 transition">
            {s.banned_users}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">Expulsión permanente</p>
        </div>

        {/* Hidden Content */}
        <div
          id="stat-hidden-content"
          onClick={() => onNavigateTab('reports', 'all')}
          className="bg-[#161B21] border border-purple-500/30 rounded-xl p-4 cursor-pointer hover:border-purple-400 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-purple-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              Contenido Ocultado
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-white group-hover:text-purple-400 transition">
            {s.hidden_content}
          </div>
          <p className="text-[11px] text-stone-400 mt-1">
            {s.hidden_dynamos} Dynamos · {s.hidden_replies} Respuestas
          </p>
        </div>

        {/* Total Reports */}
        <div
          id="stat-total-reports"
          onClick={() => onNavigateTab('reports', 'all')}
          className="bg-[#161B21] border border-stone-800 rounded-xl p-4 cursor-pointer hover:border-stone-700 hover:bg-[#1a2128] transition group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-stone-400 font-medium mb-2">
            <span className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              Total Reportes
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-stone-200 group-hover:text-white transition">
            {s.total_reports}
          </div>
          <p className="text-[11px] text-stone-500 mt-1">Historial global acumulado</p>
        </div>
      </div>

      {/* Quick Access Card */}
      <div className="bg-[#161B21] border border-stone-800 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Guía de Operación y Seguridad
        </h3>
        <p className="text-xs text-stone-400 leading-relaxed max-w-2xl">
          Las decisiones de moderación quedan grabadas con sello temporal en el registro de auditoría.
          La identidad del reportante se mantiene estrictamente confidencial ante los autores reportados
          para proteger su privacidad y prevenir represalias.
        </p>
        <div className="mt-4 flex flex-wrap gap-2.5">
          <button
            onClick={() => onNavigateTab('reports', 'pending')}
            className="px-3 py-1.5 rounded-lg bg-amber-500 text-black text-xs font-semibold hover:bg-amber-400 transition"
          >
            Revisar {s.pending_reports} reportes pendientes
          </button>
          <button
            onClick={() => onNavigateTab('users')}
            className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-200 text-xs font-medium hover:bg-stone-700 transition"
          >
            Moderar usuarios
          </button>
          <button
            onClick={() => onNavigateTab('audit')}
            className="px-3 py-1.5 rounded-lg bg-stone-800 text-stone-200 text-xs font-medium hover:bg-stone-700 transition"
          >
            Ver registro de auditoría
          </button>
        </div>
      </div>
    </div>
  );
};

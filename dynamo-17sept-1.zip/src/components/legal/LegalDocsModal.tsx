import React, { useState } from 'react';
import { FileText, Shield, HeartHandshake, AlertCircle, X, Check } from 'lucide-react';

export type LegalDocType = 'terms' | 'privacy' | 'community' | 'safety';

interface LegalDocsModalProps {
  initialDoc?: LegalDocType;
  isOpen: boolean;
  onClose: () => void;
}

export const LegalDocsModal: React.FC<LegalDocsModalProps> = ({
  initialDoc = 'terms',
  isOpen,
  onClose,
}) => {
  const [activeDoc, setActiveDoc] = useState<LegalDocType>(initialDoc);

  if (!isOpen) return null;

  return (
    <div
      id="legal-docs-modal"
      className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-xl rounded-2xl border border-stone-800 bg-[#12171E] text-stone-200 shadow-2xl flex flex-col max-h-[88vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-800/80 bg-[#151B22]">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">
                Políticas y Normas de Dynamo
              </h3>
              <p className="text-[11px] text-stone-400">
                Versión 1.4 • Actualizado 2026 • Edad mínima: 16+
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-stone-800 px-4 pt-2 bg-[#0E1318] overflow-x-auto gap-1">
          <button
            onClick={() => setActiveDoc('terms')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
              activeDoc === 'terms'
                ? 'border-amber-400 text-amber-400 bg-amber-400/5'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Términos</span>
          </button>
          <button
            onClick={() => setActiveDoc('privacy')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
              activeDoc === 'privacy'
                ? 'border-amber-400 text-amber-400 bg-amber-400/5'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Privacidad</span>
          </button>
          <button
            onClick={() => setActiveDoc('community')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
              activeDoc === 'community'
                ? 'border-amber-400 text-amber-400 bg-amber-400/5'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Comunidad</span>
          </button>
          <button
            onClick={() => setActiveDoc('safety')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
              activeDoc === 'safety'
                ? 'border-amber-400 text-amber-400 bg-amber-400/5'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Contenido & PII</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-stone-300 leading-relaxed font-sans">
          {activeDoc === 'terms' && (
            <div className="space-y-3.5">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                Términos de Servicio
              </h4>
              <p>
                <strong>1. Naturaleza Efímera:</strong> Dynamo es una red social efímera donde las publicaciones nacen con una duración inicial de 24 horas y se extinguen si no reciben regalos de energía (⚡) de otros miembros de la comunidad.
              </p>
              <p>
                <strong>2. Requisito de Edad:</strong> Debes tener al menos <strong>16 años</strong> cumplidos para crear una cuenta o participar en Dynamo. El registro por menores de 16 años está terminantemente prohibido.
              </p>
              <p>
                <strong>3. Responsabilidad de Cuenta:</strong> Eres el único custodio de tus credenciales y responsable de todas las actividades asociadas a tu nombre de usuario anónimo.
              </p>
              <p>
                <strong>4. Integridad de la Red:</strong> Queda terminantemente prohibido el empleo de robots, scripts automatizados, granjas de cuentas, explotación de la economía de energía o cualquier intento de desestabilizar la plataforma.
              </p>
              <p>
                <strong>5. Suspensión y Cierre:</strong> Dynamo se reserva el derecho de restringir, suspender o desactivar cuentas que violen estos términos o las normas de convivencia comunitaria.
              </p>
            </div>
          )}

          {activeDoc === 'privacy' && (
            <div className="space-y-3.5">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-amber-400" />
                Política de Privacidad
              </h4>
              <p>
                <strong>1. Identidad Anónima por Diseño:</strong> Tu correo electrónico se almacena de forma cifrada y <strong>nunca</strong> es mostrado públicamente en ningún perfil, feed, ranking ni interacción comunitaria.
              </p>
              <p>
                <strong>2. Cero Venta de Datos:</strong> Dynamo no comercializa, transfiere ni alquila perfiles de usuarios a corredores de datos ni plataformas publicitarias invasivas.
              </p>
              <p>
                <strong>3. Prohibición de Datos Personales (PII):</strong> Por tu seguridad, está prohibido publicar números telefónicos, direcciones domiciliarias, ubicaciones en tiempo real, identificadores gubernamentales o enlaces a chats privados.
              </p>
              <p>
                <strong>4. Control Total y Derecho al Olvido:</strong> Puedes editar tu biografía y avatar, gestionar tus preferencias de privacidad, o solicitar la eliminación total de tu cuenta en cualquier momento desde la Zona Peligrosa de Configuración.
              </p>
              <p>
                <strong>5. Cifrado y Almacenamiento:</strong> Las conexiones y tokens de sesión utilizan cifrado TLS y políticas de seguridad a nivel de fila (RLS) en la base de datos para impedir que otros usuarios accedan a tus preferencias privadas.
              </p>
            </div>
          )}

          {activeDoc === 'community' && (
            <div className="space-y-3.5">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-amber-400" />
                Normas de la Comunidad
              </h4>
              <p>
                <strong>1. Respeto y Dignidad:</strong> No se tolera el acoso, hostigamiento, discriminación, discursos de odio ni amenazas dirigidas a individuos o colectivos.
              </p>
              <p>
                <strong>2. Prohibición de Doxxing:</strong> La publicación de información privada de terceras personas sin su consentimiento expreso resulta en la suspensión inmediata y definitiva de la cuenta.
              </p>
              <p>
                <strong>3. No Spam ni Manipulación:</strong> La creación repetitiva de contenido idéntico, cadenas masivas o esquemas artificiales de recarga mutua de energía desvirtúa el espíritu efímero de Dynamo.
              </p>
              <p>
                <strong>4. Canales de Reporte:</strong> Cualquier usuario puede reportar contenido indebido mediante el botón de reporte en cada Dynamo o respuesta; un equipo de moderación audita las alertas continuamente.
              </p>
            </div>
          )}

          {activeDoc === 'safety' && (
            <div className="space-y-3.5">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                Política de Contenido Seguro y Detector PII
              </h4>
              <p>
                <strong>1. Detector de Información Personal (PII):</strong> Cada publicación, respuesta y biografía pasa por un filtro de análisis automatizado antes de ser guardada. El sistema rechaza automáticamente:
              </p>
              <ul className="list-disc list-inside pl-2 space-y-1 text-stone-400">
                <li>Números de teléfono y enlaces de WhatsApp / Telegram</li>
                <li>Correos electrónicos visibles</li>
                <li>Direcciones postales y coordenadas de ubicación exacta</li>
                <li>Números de documentos de identidad o pasaportes</li>
                <li>Datos financieros, números de tarjeta o cuentas bancarias</li>
                <li>Contraseñas o tokens de autenticación</li>
              </ul>
              <p>
                <strong>2. Contenido Prohibido:</strong> Queda vetado el contenido sexual explícito no consentido, la apología del delito, la venta de sustancias ilícitas y cualquier manifestación de violencia extrema.
              </p>
              <p>
                <strong>3. Auditoría y Transparencia:</strong> Todas las sanciones y medidas de moderación quedan registradas en un log de auditoría inviolable para garantizar la neutralidad y transparencia del sistema.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-stone-800 bg-[#151B22]">
          <div className="flex items-center gap-1 text-[11px] text-stone-400">
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>Protegido por reglas de cifrado RLS</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold transition"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
